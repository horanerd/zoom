<?php

namespace Guzzle\Common;

/**
 * Guzzle exception
 *
 * @author Michael Dowling <michael@guzzlephp.org>
 */
interface GuzzleException
{
}